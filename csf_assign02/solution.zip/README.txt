Mohammed Siam (JHED: msiam1)
Iason Mihalopoulos (JHED: imihalo1)

Milestone 1 (20%):
Siam:
    wc_hash - done
    wc_str_copy - done
    wc_isalpha - done
    wc_tolower - done
    wc_find_or_insert - done
    wc_free_chain - done

Jason:
    wc_str_compare - done
    wc_isspace - done
    wc_readnext - done
    wc_trim_non_alpha - done
    wc_dict_find_or_insert - done

C implementation of the main program (in c_wcmain.c) - done
Assembly language implementations of the following functions (in asm_wcfuncs.S):
    wc_isspace - done
    wc_isalpha - done
    wc_str_compare


Milestone 2 (80%):

Assembly language implementations of all remaining functions (in asm_wcfuncs.S)
Assembly language implementation of the main program (in asm_wcmain.S, 4% of assignment grade)
Design and coding style (10% of assignment grade)